﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Firebase.Database;

public class Briefing : MonoBehaviour
{
    bool getRank = false;

    IEnumerator Start()
    {
        CheckRank();

        yield return new WaitForSeconds(2f);

        MainFlow.Instance.SetCurStageIdx(1);
        MainFlow.Instance.SceneConversion("1");
    }

    void CheckRank()
    {
        getRank = false;

        DatabaseReference r = FirebaseDatabase.DefaultInstance.RootReference;

        string uuid = SystemInfo.deviceUniqueIdentifier;

        r.Child("rank").Child(uuid).GetValueAsync().ContinueWith(task =>
        {
            if (task.IsFaulted)
                Debug.LogError("error");
            else if (task.IsCompleted)
            {
                DataSnapshot dss = task.Result;
                Debug.Log(dss.ChildrenCount);

                foreach (DataSnapshot node in dss.Children)
                {
                    Debug.Log("key = " + node.Key);

                    IDictionary info = node.Value as IDictionary;
                    if (info == null)
                    {
                        Debug.LogWarning("info is not IDictionary");
                        continue;
                    }
                    if (info.Contains("name") == true && info.Contains("v") == true)
                        Debug.Log("name:" + info["name"] + ", v:" + info["v"]);
                    else
                        Debug.LogWarning("containing name = " + info.Contains("name") + ", containing v = " + info.Contains("v"));
                }

                getRank = true;
            }
        });
    }
}
