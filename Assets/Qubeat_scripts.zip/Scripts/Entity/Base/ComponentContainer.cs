using UnityEngine;
using System.Collections;

public class ComponentContainer : MonoBehaviour
{
	public YCollider col_;
	public YSpinner spinner_;
	public YMover mover_;
}

