using UnityEngine;
using System.Collections;

public class StoneState_Idle : YBaseState<Stone>
{
	public StoneState_Idle(YStateMachine<Stone> _sm) : base (_sm)
	{
	}
	
	public override void Enter(YMessage _msg)
	{
	}
	
	public override void Update()
	{
	}
	
	public override void Exit(YMessage _msg)
	{
	}
}

