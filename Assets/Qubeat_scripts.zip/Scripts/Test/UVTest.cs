using UnityEngine;
using System.Collections;

public class UVTest : MonoBehaviour {

	// Use this for initialization
	void Start () {
//		MeshFilter mesh = GetComponent<MeshFilter>().mesh;
//		Vector2[] uv = mesh.uv;
//		
//		float seed = Random.Range(0f, 4f) * 0.25f;
//		for(int i=0; i<uv.Length; ++i)
//		{
//			uv[i] = new Vector2(seed, seed);
//		}
//		
//		mesh.uv = uv;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
