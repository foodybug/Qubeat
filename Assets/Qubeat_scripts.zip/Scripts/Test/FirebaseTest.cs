﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Firebase;
using Firebase.Database;
//using Firebase.Unity;

public class FirebaseTest : MonoBehaviour
{
    [SerializeField] TestInfo info;

    [SerializeField] bool save = false;
    [SerializeField] bool load = false;
    [Range(0, 100)][SerializeField] int loadID = 0;

    void Start()
    {
        DatabaseReference r = FirebaseDatabase.DefaultInstance.RootReference;
        Query d = r.OrderByChild("v").StartAt(900);
        d.GetValueAsync().ContinueWith(task =>
        {
            DataSnapshot dss = task.Result;
            Debug.Log(dss.ChildrenCount);

            foreach (DataSnapshot node in dss.Children)
            {
                //Debug.Log("key = " + node.Key);

                IDictionary info = node.Value as IDictionary;
                if (info == null)
                {
                    Debug.LogWarning("info is not IDictionary");
                    continue;
                }

                if (info.Contains("name") == true && info.Contains("v") == true)
                    Debug.Log("name:" + info["name"] + ", v:" + info["v"]);
                else
                    Debug.LogWarning("containing name = " + info.Contains("name") + ", containing v = " + info.Contains("v"));
            }
        });

        //if(save == true)
        //{
        //    for (int i = 0; i < 100; ++i)
        //    {
        //        string json = JsonUtility.ToJson(info);
        //        r.Child(info.name).SetRawJsonValueAsync(json);
        //        if (UnityEngine.Random.Range(0, 3) == 0)
        //        {
        //            r.Child(info.name).Child("child").SetRawJsonValueAsync(json);
        //        }

        //        info.Random();
        //    }
        //}

        //if(load == true)
        //{
        //    r.Child("user" + loadID).GetValueAsync().ContinueWith(task =>
        //    {
        //        if (task.IsFaulted)
        //            Debug.LogError("error");
        //        else if(task.IsCompleted)
        //        {
        //            DataSnapshot dss = task.Result;
        //            Debug.Log(dss.ChildrenCount);

        //            foreach(DataSnapshot node in dss.Children)
        //            {
        //                Debug.Log("key = " + node.Key);

        //                IDictionary info = node.Value as IDictionary;
        //                if (info == null)
        //                {
        //                    Debug.LogWarning("info is not IDictionary");
        //                    continue;
        //                }
        //                if (info.Contains("name") == true && info.Contains("v") == true)
        //                    Debug.Log("name:" + info["name"] + ", v:" + info["v"]);
        //                else
        //                    Debug.LogWarning("containing name = " + info.Contains("name") + ", containing v = " + info.Contains("v"));
        //            }
        //        }
        //    });
        //}
    }



    [Serializable]
    class TestInfo
    {
        public string name;
        public int v;

        public void Random()
        {
            name = "user" + UnityEngine.Random.Range(0, 100);
            v = UnityEngine.Random.Range(0, 1000);
        }
    }
}
