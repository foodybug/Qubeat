using UnityEngine;
using System.Collections;

public class Music_Name : MonoBehaviour {
	
	[SerializeField] Vector2 m_ScreenPos;

	// Use this for initialization
	void Start () {
		transform.position = m_ScreenPos;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
